DROP TABLE t_usuario CASCADE CONSTRAINTS;

DROP TABLE t_endereco CASCADE CONSTRAINTS;

DROP TABLE t_posto_saude CASCADE CONSTRAINTS;

DROP TABLE t_medicamento CASCADE CONSTRAINTS;

DROP TABLE t_medicamento_posto CASCADE CONSTRAINTS;

DROP TABLE t_retirada CASCADE CONSTRAINTS;

DROP SEQUENCE seq_t_endereco;

DROP SEQUENCE seq_t_medicamento;

DROP SEQUENCE seq_t_medicamento_posto;

DROP SEQUENCE seq_t_posto_saude;

DROP SEQUENCE seq_t_retirada;

DROP SEQUENCE seq_t_usuario;
