--tabela t_endereco
INSERT INTO t_endereco (id_endereco, ds_logradouro, nr_logradouro, ds_complemento, nr_cep, ds_estado, ds_cidade, sg_ativo)
VALUES (SEQ_T_ENDERECO.NEXTVAL, 'Rua das Flores', '123', 'Apto 45', '12345678', 'São Paulo', 'São Paulo', 'A');

INSERT INTO t_endereco (id_endereco, ds_logradouro, nr_logradouro, ds_complemento, nr_cep, ds_estado, ds_cidade, sg_ativo)
VALUES (SEQ_T_ENDERECO.NEXTVAL, 'Avenida Paulista', '456', 'Bloco 2', '23456789', 'São Paulo', 'São Paulo', 'A');

INSERT INTO t_endereco (id_endereco, ds_logradouro, nr_logradouro, ds_complemento, nr_cep, ds_estado, ds_cidade, sg_ativo)
VALUES (SEQ_T_ENDERECO.NEXTVAL, 'Rua das Margaridas', '789', 'Apto 12', '34567891', 'São Paulo', 'São Paulo', 'A');

INSERT INTO t_endereco (id_endereco, ds_logradouro, nr_logradouro, ds_complemento, nr_cep, ds_estado, ds_cidade, sg_ativo)
VALUES (SEQ_T_ENDERECO.NEXTVAL, 'Avenida Brasil', '1011', 'Bloco 3', '45678912', 'São Paulo', 'São Paulo', 'A');

INSERT INTO t_endereco (id_endereco, ds_logradouro, nr_logradouro, ds_complemento, nr_cep, ds_estado, ds_cidade, sg_ativo)
VALUES (SEQ_T_ENDERECO.NEXTVAL, 'Rua das Orquídeas', '1314', 'Apto 67', '56789123', 'São Paulo', 'São Paulo', 'A');

--tabela t_usuario
INSERT INTO t_usuario (id_usuario, id_endereco, ds_email, nm_usuario, nr_telefone, sg_tipo, sg_ativo)
VALUES (SEQ_T_USUARIO.NEXTVAL, 1, 'joao@gmail.com', 'João Silva', '123456789', 'A', 'A');

INSERT INTO t_usuario (id_usuario, id_endereco, ds_email, nm_usuario, nr_telefone, sg_tipo, sg_ativo)
VALUES (SEQ_T_USUARIO.NEXTVAL, 2, 'maria@gmail.com', 'Maria Oliveira', '987654321', 'P', 'A');

INSERT INTO t_usuario (id_usuario, id_endereco, ds_email, nm_usuario, nr_telefone, sg_tipo, sg_ativo)
VALUES (SEQ_T_USUARIO.NEXTVAL, 3, 'carlos@gmail.com', 'Carlos Santos', '234567891', 'A', 'A');

INSERT INTO t_usuario (id_usuario, id_endereco, ds_email, nm_usuario, nr_telefone, sg_tipo, sg_ativo)
VALUES (SEQ_T_USUARIO.NEXTVAL, 4, 'ana@gmail.com', 'Ana Pereira', '345678912', 'P', 'A');

INSERT INTO t_usuario (id_usuario, id_endereco, ds_email, nm_usuario, nr_telefone, sg_tipo, sg_ativo)
VALUES (SEQ_T_USUARIO.NEXTVAL, 5, 'pedro@gmail.com', 'Pedro Costa', '456789123', 'A', 'A');


--tabela t_posto_saude
INSERT INTO t_posto_saude (id_posto, id_endereco, nm_posto, ds_descricao, sg_ativo)
VALUES (SEQ_T_POSTO_SAUDE.NEXTVAL, 1, 'Posto Saúde Central', 'Posto de saúde central da cidade', 'A');

INSERT INTO t_posto_saude (id_posto, id_endereco, nm_posto, ds_descricao, sg_ativo)
VALUES (SEQ_T_POSTO_SAUDE.NEXTVAL, 2, 'Posto Saúde Paulista', 'Posto de saúde da avenida paulista', 'A');

INSERT INTO t_posto_saude (id_posto, id_endereco, nm_posto, ds_descricao, sg_ativo)
VALUES (SEQ_T_POSTO_SAUDE.NEXTVAL, 3, 'Posto Saúde Jardim', 'Posto de saúde do jardim das flores', 'A');

INSERT INTO t_posto_saude (id_posto, id_endereco, nm_posto, ds_descricao, sg_ativo)
VALUES (SEQ_T_POSTO_SAUDE.NEXTVAL, 4, 'Posto Saúde Brasil', 'Posto de saúde da avenida brasil', 'A');

INSERT INTO t_posto_saude (id_posto, id_endereco, nm_posto, ds_descricao, sg_ativo)
VALUES (SEQ_T_POSTO_SAUDE.NEXTVAL, 5, 'Posto Saúde Orquídeas', 'Posto de saúde da rua das orquídeas', 'A');

--tabela t_medicamento
INSERT INTO t_medicamento (id_medicamento, nm_medicamento, nm_fabricante, nr_dose)
VALUES (SEQ_T_MEDICAMENTO.NEXTVAL, 'Paracetamol', 'Medley', '500mg');

INSERT INTO t_medicamento (id_medicamento, nm_medicamento, nm_fabricante, nr_dose)
VALUES (SEQ_T_MEDICAMENTO.NEXTVAL, 'Ibuprofeno', 'Neo Química', '400mg');

INSERT INTO t_medicamento (id_medicamento, nm_medicamento, nm_fabricante, nr_dose)
VALUES (SEQ_T_MEDICAMENTO.NEXTVAL, 'Dipirona', 'Medley', '500mg');

INSERT INTO t_medicamento (id_medicamento, nm_medicamento, nm_fabricante, nr_dose)
VALUES (SEQ_T_MEDICAMENTO.NEXTVAL, 'Amoxicilina', 'Neo Química', '500mg');

INSERT INTO t_medicamento (id_medicamento, nm_medicamento, nm_fabricante, nr_dose)
VALUES (SEQ_T_MEDICAMENTO.NEXTVAL, 'Azitromicina', 'Medley', '500mg');


