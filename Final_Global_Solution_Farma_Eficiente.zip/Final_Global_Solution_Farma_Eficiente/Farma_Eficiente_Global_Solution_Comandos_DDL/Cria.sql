CREATE TABLE t_usuario (
    id_usuario  NUMBER(9) NOT NULL,
    id_endereco NUMBER(9) NOT NULL,
    ds_email    VARCHAR2(50) NOT NULL,
    nm_usuario  VARCHAR2(40) NOT NULL,
    nr_telefone VARCHAR2(9) NOT NULL,
    sg_tipo     CHAR(1) NOT NULL,
    sg_ativo    CHAR(1) DEFAULT 'A' NOT NULL
);

ALTER TABLE t_usuario
    ADD CHECK ( sg_tipo IN ( 'A', 'P' ) );

ALTER TABLE t_usuario
    ADD CHECK ( sg_ativo IN ( 'A', 'I' ) );

CREATE UNIQUE INDEX t_usuario__idx ON
    t_usuario (
        id_endereco
    ASC );

ALTER TABLE t_usuario ADD CONSTRAINT pk_t_usuario PRIMARY KEY ( id_usuario );

ALTER TABLE t_usuario ADD CONSTRAINT uk_ds_email UNIQUE ( ds_email );

CREATE TABLE t_endereco (
    id_endereco    NUMBER(9) NOT NULL,
    ds_logradouro  VARCHAR2(50) NOT NULL,
    nr_logradouro  VARCHAR2(10) NOT NULL,
    ds_complemento VARCHAR2(15),
    nr_cep         VARCHAR2(8) NOT NULL,
    ds_estado      VARCHAR2(25) NOT NULL,
    ds_cidade      VARCHAR2(25) NOT NULL,
    sg_ativo       CHAR(1) DEFAULT 'A' NOT NULL
);

ALTER TABLE t_endereco
    ADD CHECK ( sg_ativo IN ( 'A', 'I' ) );

ALTER TABLE t_endereco ADD CONSTRAINT pk_t_endereco PRIMARY KEY ( id_endereco );

CREATE TABLE t_posto_saude (
    id_posto     NUMBER(9) NOT NULL,
    id_endereco  NUMBER(9) NOT NULL,
    nm_posto     VARCHAR2(50) NOT NULL,
    ds_descricao VARCHAR2(200) NOT NULL,
    sg_ativo     CHAR(1) DEFAULT 'A' NOT NULL
);

ALTER TABLE t_posto_saude
    ADD CHECK ( sg_ativo IN ( 'A', 'I' ) );

CREATE UNIQUE INDEX t_posto_saude__idx ON
    t_posto_saude (
        id_endereco
    ASC );

ALTER TABLE t_posto_saude ADD CONSTRAINT pk_t_posto_saude PRIMARY KEY ( id_posto );

CREATE TABLE t_medicamento (
    id_medicamento NUMBER(9) NOT NULL,
    nm_medicamento VARCHAR2(50) NOT NULL,
    nm_fabricante  VARCHAR2(50) NOT NULL,
    nr_dose        VARCHAR2(10) NOT NULL
);

ALTER TABLE t_medicamento ADD CONSTRAINT t_medicamento_pk PRIMARY KEY ( id_medicamento );

CREATE TABLE t_medicamento_posto (
    id_posto             NUMBER(9) NOT NULL,
    nr_estoque           NUMBER(5) NOT NULL,
    id_medicamento       NUMBER(9) NOT NULL,
    id_medicamento_posto NUMBER(9) NOT NULL
);

ALTER TABLE t_medicamento_posto ADD CONSTRAINT t_medicamento_posto_pk PRIMARY KEY ( id_medicamento_posto );

CREATE TABLE t_retirada (
    id_retirada          NUMBER(9) NOT NULL,
    id_usuario           NUMBER(9) NOT NULL,
    dt_retirada          DATE NOT NULL,
    id_medicamento_posto NUMBER(9) NOT NULL
);

ALTER TABLE t_retirada ADD CONSTRAINT pk_t_retirada PRIMARY KEY ( id_retirada );

ALTER TABLE t_medicamento_posto
    ADD CONSTRAINT fk_medicamento_posto FOREIGN KEY ( id_medicamento )
        REFERENCES t_medicamento ( id_medicamento );

ALTER TABLE t_retirada
    ADD CONSTRAINT fk_medicamento_retirada FOREIGN KEY ( id_medicamento_posto )
        REFERENCES t_medicamento_posto ( id_medicamento_posto );

ALTER TABLE t_posto_saude
    ADD CONSTRAINT fk_posto_endereco FOREIGN KEY ( id_endereco )
        REFERENCES t_endereco ( id_endereco );

ALTER TABLE t_medicamento_posto
    ADD CONSTRAINT fk_posto_medicamento FOREIGN KEY ( id_posto )
        REFERENCES t_posto_saude ( id_posto );

ALTER TABLE t_usuario
    ADD CONSTRAINT fk_usuario_endereco FOREIGN KEY ( id_endereco )
        REFERENCES t_endereco ( id_endereco );

ALTER TABLE t_retirada
    ADD CONSTRAINT fk_usuario_retirada FOREIGN KEY ( id_usuario )
        REFERENCES t_usuario ( id_usuario );


CREATE SEQUENCE SEQ_T_USUARIO START WITH 1 INCREMENT BY 1 NOCACHE;

CREATE SEQUENCE SEQ_T_ENDERECO START WITH 1 INCREMENT BY 1 NOCACHE;

CREATE SEQUENCE SEQ_T_POSTO_SAUDE START WITH 1 INCREMENT BY 1 NOCACHE;

CREATE SEQUENCE SEQ_T_MEDICAMENTO START WITH 1 INCREMENT BY 1 NOCACHE;

CREATE SEQUENCE SEQ_T_RETIRADA START WITH 1 INCREMENT BY 1 NOCACHE;

CREATE SEQUENCE seq_t_medicamento_posto START WITH 1 INCREMENT BY 1 NOCACHE;