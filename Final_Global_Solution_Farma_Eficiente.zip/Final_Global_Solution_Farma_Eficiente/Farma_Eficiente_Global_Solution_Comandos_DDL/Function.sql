CREATE OR REPLACE FUNCTION contarMedicamentosPorFabricante(nomeFabricante IN VARCHAR2) RETURN NUMBER IS
    totalMedicamentos NUMBER;
BEGIN
    SELECT COUNT(*)
    INTO totalMedicamentos
    FROM t_medicamento
    WHERE nm_fabricante = nomeFabricante;

    RETURN totalMedicamentos;
EXCEPTION
    WHEN OTHERS THEN
        RETURN -1; 
END;




