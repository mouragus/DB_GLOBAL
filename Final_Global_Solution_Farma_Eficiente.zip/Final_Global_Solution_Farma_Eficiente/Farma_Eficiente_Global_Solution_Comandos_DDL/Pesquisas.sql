CREATE OR REPLACE PROCEDURE PESQUISA_USUARIO_ENDERECO(
    tipo_pesquisa IN VARCHAR2
) IS
    v_usuario t_usuario%ROWTYPE;
    v_endereco t_endereco%ROWTYPE;
BEGIN
    IF tipo_pesquisa = 'USUARIO' THEN
        DECLARE
            CURSOR c_usuario IS
                SELECT * FROM t_usuario WHERE nm_usuario = 'João Silva'; 
        BEGIN
            OPEN c_usuario;
            FETCH c_usuario INTO v_usuario;
            CLOSE c_usuario;

            DBMS_OUTPUT.PUT_LINE('Usuário Encontrado:');
            DBMS_OUTPUT.PUT_LINE('ID: ' || v_usuario.id_usuario);
            DBMS_OUTPUT.PUT_LINE('Nome: ' || v_usuario.nm_usuario);
        END;
    ELSIF tipo_pesquisa = 'ENDERECO' THEN
        DECLARE
            CURSOR c_endereco IS
                SELECT * FROM t_endereco WHERE ds_logradouro = 'Rua das Flores'; 
        BEGIN
            OPEN c_endereco;
            FETCH c_endereco INTO v_endereco;
            CLOSE c_endereco;

           
            DBMS_OUTPUT.PUT_LINE('Endereço Encontrado:');
            DBMS_OUTPUT.PUT_LINE('ID: ' || v_endereco.id_endereco);
            DBMS_OUTPUT.PUT_LINE('Logradouro: ' || v_endereco.ds_logradouro);
        END;
    ELSE
        DBMS_OUTPUT.PUT_LINE('Tipo de pesquisa inválido');
    END IF;
END PESQUISA_USUARIO_ENDERECO;
/



BEGIN
    PESQUISA_USUARIO_ENDERECO('USUARIO'); -- Para buscar informações de usuário
    PESQUISA_USUARIO_ENDERECO('ENDERECO'); -- Para buscar informações de endereço
END;


